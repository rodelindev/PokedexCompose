package com.developer.pokedexcompose.ui.screens.pokemondetail

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController

@Composable
fun PokemonDetailScreen(
    navController: NavController,
    dominantColor: Color,
    pokemonName: String
) {

}